# sensorcloud_services
This is a custom library to interact with AWS services.
